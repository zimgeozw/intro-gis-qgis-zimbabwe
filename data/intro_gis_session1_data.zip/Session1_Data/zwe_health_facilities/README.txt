Zimbabwe health facilities (1,470 points)
=========================================

Format: ESRI Shapefile, UTF-8. Coordinate system: WGS 84 (EPSG:4326).

Fields: fac_id, name, fac_type (Clinic, Rural Health Centre, District Hospital ...), district, year_built,
doctors, nurses, beds, catchm_pop (catchment population), longitude, latitude.
Empty values mean 'not recorded' (the original data stored these as 0). Most facilities have no staffing or bed data.
zwe_health_facilities.csv is the same data as a table, for practising 'Add delimited text layer' with the longitude and latitude columns.

Source: Ministry of Health and Child Welfare (MoHCW), Zimbabwe, health facility database (file zwe_health_facility_mohcw),
data recorded up to about 2007, as distributed for humanitarian use. Prepared by Zimgeo: field names shortened,
facility types tidied (e.g. 'clinic' to 'Clinic'), 0 replaced by empty, 10 records without a location removed.
The data is old: facilities built since 2007 are missing and some details may have changed. Date your maps accordingly.

Contact: Zimgeo, aldridge@zimgeo.co.zw, www.zimgeo.co.zw
