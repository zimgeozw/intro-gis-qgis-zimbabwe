Zimbabwe rail network (59 line segments, about 2,780 km)
========================================================

Format: ESRI Shapefile, UTF-8. Coordinate system: WGS 84 (EPSG:4326).

Fields: rail_id, length_km (geodesic length of each segment)

Source: Department of the Surveyor General, Zimbabwe, 1:250,000 topographic base data (file zwe_rail_network_250k_dsg),
as distributed for humanitarian use. Prepared by Zimgeo: original coded fields replaced with an ID and length in km.
Scale 1:250,000: suitable for national and provincial maps, not for site-level work.

Contact: Zimgeo, aldridge@zimgeo.co.zw, www.zimgeo.co.zw
