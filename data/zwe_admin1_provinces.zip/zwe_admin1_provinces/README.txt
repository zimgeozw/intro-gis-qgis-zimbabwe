Zimbabwe level 1: provinces (10 polygons)
=========================================

Format: ESRI Shapefile, UTF-8. Coordinate system: WGS 84 (EPSG:4326).

Fields: province, prov_pcode, country, area_km2, valid_on, source

Source: Zimbabwe National Statistics Agency (ZIMSTAT) and OCHA ROSEA, Common Operational Dataset of
administrative boundaries (COD-AB), valid from 11 September 2018, Humanitarian Data Exchange
(https://data.humdata.org/dataset/cod-ab-zwe). Licence: CC BY-IGO. Credit the source on published maps.
Prepared by Zimgeo (www.zimgeo.co.zw): P-codes kept, parent unit names added, areas calculated on the WGS 84 ellipsoid.

Contact: Zimgeo, aldridge@zimgeo.co.zw, www.zimgeo.co.zw
